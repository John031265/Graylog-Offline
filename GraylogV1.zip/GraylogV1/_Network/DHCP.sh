sudo cp /etc/netplan/00-installer-config.DHCP /etc/netplan/00-installer-config.yaml
