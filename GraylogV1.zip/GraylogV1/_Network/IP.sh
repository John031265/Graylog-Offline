sudo cp /etc/netplan/00-installer-config.IP /etc/netplan/00-installer-config.yaml
